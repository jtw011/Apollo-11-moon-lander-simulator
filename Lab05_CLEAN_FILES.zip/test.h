/***********************************************************************
 * Header File:
 *    TEST
 * Author:
 *    Br. Helfrich
 * Summary:
 *    The test runner
 ************************************************************************/

#pragma once
void testRunner();
